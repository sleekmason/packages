#!/bin/sh
# Place items you want started when awesome starts.
# Make sure to add a '&' symbol. 
xfsettingsd --daemon &
lxpolkit &
pnmixer &
# ~/.fehbg &
# picom &
nm-applet &
# Start awesome
exec awesome
