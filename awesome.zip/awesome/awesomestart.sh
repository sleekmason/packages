#!/bin/sh
# Place items you want started when dwm starts, here. Make sure to add
# an '&' symbol. 
xfsettingsd --daemon &
lxpolkit &
#~/.fehbg &
pnmixer &
picom &
bright-gamma &
nm-applet &
sleep 20 && kdocker -i "/usr/share/icons/hicolor/16x16/apps/thunderbird.png" -jl thunderbird >/dev/null 2>&1 &
# Start awesome
exec awesome
