#!/bin/sh
# Place items you want started when awesome starts.
# ensure only one instance..
run() {
  if ! pgrep -f "$1" ;
  then
    "$@"&
  fi
}
# Add programs to run @ startup "run" insures the check.
run "xfsettingsd"
run "lxpolkit"
run "pnmixer"
run "$HOME/.fehbg"
#run "picom"
run "nm-applet"

# Run awesome-user-autostart.sh for additional user items.
if test -f  "$HOME/.config/awesome/awesome-user-autostart.sh"; then
	~/.config/awesome/awesome-user-autostart.sh
fi
