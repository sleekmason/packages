#!/bin/bash
# Display Wayfire keybindings
# Created for Waydog by sleekmason 3 Jan 2026

CONFIG="$HOME/.config/wayfire.ini"

if command -v x-terminal-emulator >/dev/null 2>&1; then
    REAL_TERM=$(basename "$(readlink -f "$(command -v x-terminal-emulator)")")
else
    notify-send "wayfire-keys" "No terminal emulator found"
    exit 1
fi

run_in_terminal() {
    SCRIPT="$1"
    case "$REAL_TERM" in
        ghostty)        x-terminal-emulator --title="Wayfire Keybinds" -e "$SCRIPT" ;;
        xfce4-terminal) x-terminal-emulator -T "Wayfire Keybinds" -x "$SCRIPT" ;;
        alacritty)      x-terminal-emulator --title "Wayfire Keybinds" -e "$SCRIPT" ;;
        gnome-terminal) x-terminal-emulator -T "Wayfire Keybinds" -- "$SCRIPT" ;;
        foot)           x-terminal-emulator --title="Wayfire Keybinds" -e "$SCRIPT" ;;
        kitty)          x-terminal-emulator --title="Wayfire Keybinds" -e "$SCRIPT" ;;
        wezterm)        x-terminal-emulator start --title "Wayfire Keybinds" "$SCRIPT" ;;
        *)              x-terminal-emulator -e "$SCRIPT" ;;
    esac
}

TMP_SCRIPT=$(mktemp)

cat >"$TMP_SCRIPT" <<'EOF'
#!/bin/bash
CONFIG="$HOME/.config/wayfire.ini"
clear

# Colors
HEAD_COLOR="\033[94m"
GREEN="\033[32m"
BLUE="\033[34m"
RESET="\033[0m"

echo -e " ${BLUE}WAYFIRE KEYBINDS   Legend: Mod=Super  S=Shift  C=Ctrl${RESET}"
echo -e " ${GREEN}--------------------------------------------------------${RESET}"

awk -v HEAD="$HEAD_COLOR" -v RESET="$RESET" '
function fmt(action, key, val,   k, a) {
    k = key; a = action
    if (action in extras) { k = action; a = tolower(action) }
    return sprintf(" %s%-*s%s  %s%-*s%s - %s%s%s\n",
        CKEY, width_key, k, RESET,
        CACT, width_act, a, RESET,
        CDET, val, RESET)
}
BEGIN {
    CKEY="\033[33m"
    CACT="\033[32m"
    CDET="\033[34m"
    width_key=24
    width_act=14
    in_user=0
    EXTRAS = "Desktop"
    split("Activate Cube|Invert|Wayfire Shell|Move Windows|Resize Windows|Rotate Windows|Fisheye|Zoom Desktop|Change Opacity", t, "|")
    for (i in t) extras[t[i]] = 1
}

# Parse lines and categorize
{
    # Detect User Commands block
    if ($0 ~ /^\[/) { sect=$0; gsub(/[][]/, "", sect) }
    if ($0 ~ /# User programs begin/) { in_user=1; next }
    if ($0 ~ /# User programs end/)   { in_user=0; next }

    if ($0 ~ /^[ \t]*binding_/ || $0 ~ /^[ \t]*repeatable_binding_/ || $0 ~ /^[a-zA-Z0-9_-]+[ \t]*=/) {
        line=$0
        gsub(/^[ \t]+|[ \t]+$/, "", line)
        split(line, a, "=")
        key=a[1]
        val=a[2]
        gsub(/^[ \t]+|[ \t]+$/, "", key)
        gsub(/^[ \t]+|[ \t]+$/, "", val)

        gsub(/^binding_|^repeatable_binding_/, "", key)
        gsub(/KEY_/, "", val)

        # Normalize modifiers first
        gsub(/<super>/, "Super", val)
        gsub(/<shift>/, "Shift", val)
        gsub(/<ctrl>/,  "Ctrl",  val)
        gsub(/<alt>/,   "Alt",   val)
        gsub(/SYSRQ/, "Print", val)

        n = split(val, parts, "|")
        for (i = 1; i <= n; i++) {
            gsub(/[ ]+/, "+", parts[i])
            gsub(/^\+|\+$/, "", parts[i])
        }
        val = parts[1]
        for (i = 2; i <= n; i++) val = val " | " parts[i]

        if (key ~ /^command_/) next

        action=""

        if (in_user && key != "") {
            action="User Commands"
        }
        else if (key ~ /panel-toggle/) action="Panel"
        else if (key ~ /lock/) action="Lock"
        else if (key ~ /screenshot/) action="Screenshot"
        else if (key ~ /volume/) action="Volume"
        else if (key ~ /light/) action="Brightness"
        else if (key ~ /^(left|right|up|down)$/ || key ~ /^with_win_/) action="Workspace/Move"
        else if (key ~ /^slot_|^restore$/) action="Workspace Slots"
        else if (key == "toggle" && sect == "expo") action="Expo"
        else if (key ~ /^select_workspace_/) action="Expo"
        else if (key ~ /^next_output/) action="Outputs"
        else if (key == "toggle" && sect == "invert") action="Invert"
        else if (key == "toggle_menu") action="Wayfire Shell"
        else if (key ~ /^next_view|^prev_view|^activate$/ && val ~ /TAB|ESC/) action="Window Switch"
        else if ((key == "activate") && (val ~ /BTN_LEFT/) && (val !~ /Ctrl/)) action="Move Windows"
        else if ((key == "activate") && (val ~ /BTN_LEFT/) && (val ~ /Ctrl/)) action="Activate Cube"
        else if ((key == "activate") && (val ~ /BTN_RIGHT/) && (val !~ /Ctrl/)) action="Resize Windows"
        else if ((key == "activate") && (val ~ /BTN_RIGHT/) && (val ~ /Ctrl/)) action="Rotate Windows"
        else if (key == "toggle" && sect == "fisheye") action="Fisheye"
        else next

        lines[action] = lines[action] fmt(action, key, val)
    }

    # Zoom Desktop (super + scroll)
    else if ($0 ~ /^\[zoom\]/) {
        getline
        if ($0 ~ /modifier[ \t]*=/) {
            val=$0
            gsub(/.*= */, "", val)
            gsub(/<super>/, "Super", val)
            val = val " + MouseScroll"
            action="Zoom Desktop"
            lines[action] = lines[action] fmt(action, "zoom", val)
        }
    }

    # Change Opacity (super + alt + scroll)
    else if ($0 ~ /^\[alpha\]/) {
        getline
        if ($0 ~ /modifier[ \t]*=/) {
            val=$0
            gsub(/.*= */, "", val)
            gsub(/<super>/, "Super", val)
            gsub(/<alt>/, "Alt", val)
            val = val " + MouseScroll"
            action="Change Opacity"
            lines[action] = lines[action] fmt(action, "alpha", val)
        }
    }
}

END {
    preferred_order[1]  = "User Commands"
    preferred_order[2]  = "Screenshot"
    preferred_order[3]  = "Lock"
    preferred_order[4]  = "Panel"
    preferred_order[5]  = "Outputs"
    preferred_order[6]  = "Volume"
    preferred_order[7]  = "Brightness"
    preferred_order[8]  = "Workspace Slots"
    preferred_order[9]  = "Window Switch"
    preferred_order[10] = "Workspace/Move"
    preferred_order[11] = "Expo"
    preferred_order[12] = "Move Windows"
    preferred_order[13] = "Resize Windows"
    preferred_order[14] = "Rotate Windows"
    preferred_order[15] = "Activate Cube"
    preferred_order[16] = "Invert"
    preferred_order[17] = "Wayfire Shell"
    preferred_order[18] = "Fisheye"
    preferred_order[19] = "Zoom Desktop"
    preferred_order[20] = "Change Opacity"

    for (i = 1; i <= 20; i++) {
        action = preferred_order[i]
        if (lines[action] == "") continue
        if (action in extras) {
            if (!extras_head++) print "\n" HEAD "[" EXTRAS "]" RESET
        } else
            print "\n" HEAD "[" action "]" RESET
        printf "%s", lines[action]
    }
}
' "$CONFIG"

echo -e " ${GREEN}--------------------------------------------------------${RESET}"
echo
read -n1 -s -r -p "Press any key to close..."
echo
EOF

chmod +x "$TMP_SCRIPT"
run_in_terminal "$TMP_SCRIPT"
rm -f "$TMP_SCRIPT"
