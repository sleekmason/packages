"""Init module for TLPUI."""

__version__ = "1.6.1"
