/* See LICENSE file for copyright and license details. */

/* multimedia keys */
#include <X11/XF86keysym.h>

/* appearance */
static const unsigned int borderpx  = 1;        /* border pixel of windows */
static const int startwithgaps[]    = { 1 };	/* 1 means gaps are used by default, this can be customized for each tag */
static const unsigned int gappx[]   = { 10 };   /* default gap between windows in pixels, this can be customized for each tag */
static const unsigned int snap      = 32;       /* snap pixel */
static const unsigned int systraypinning = 0;   /* 0: sloppy systray follows selected monitor, >0: pin systray to monitor X */
static const unsigned int systrayonleft = 0;    /* 0: systray in the right corner, >0: systray on left of status text */
static const unsigned int systrayspacing = 2;   /* systray spacing */
static const int systraypinningfailfirst = 0;   /* 1: if pinning fails, display systray on the first monitor, False: display systray on the last monitor*/
static const int showsystray        = 1;        /* 0 means no systray */
static const int showbar            = 1;        /* 0 means no bar */
static const int topbar             = 1;        /* 0 means bottom bar */
static const char buttonbar[]       = "[M]";
static const char *fonts[]          = { "JetBrains Mono:size=10:antialias=true:autohint=true" };
static const char dmenufont[]       = "DejaVu Sans:size=10:antialias=true:autohint=true";
static const char col_gray1[]       = "#101314";
static const char col_gray2[]       = "#3A4144";
static const char col_gray3[]       = "#B9BCBD";
static const char col_gray4[]       = "#F5F8FA";
static const char col_cyan[]        = "#2B5366";
static const char *colors[][3]      = {
	/*               fg         bg         border   */
	[SchemeNorm] = { col_gray3, col_gray1, col_gray2 },
	[SchemeSel]  = { col_gray4, col_cyan,  col_cyan  },
	[SchemeHov]  = { col_gray4, col_cyan,  col_cyan  },
	[SchemeHid]  = { col_cyan,  col_gray1, col_cyan  },
};

/* tagging */
static const char *tags[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9" };

static const Rule rules[] = {
	/* xprop(1):
	 *	WM_CLASS(STRING) = instance, class
	 *	WM_NAME(STRING) = title
	 */
	/* class      instance    title       tags mask     isfloating   monitor    float x,y,w,h         floatborderpx*/
	{ "Gammy",       NULL,       NULL,       0,            1,           -1,        50,50,250,250,        3 }, 
	{ "Lxappearance",NULL,       NULL,       0,            1,           -1,        50,50,500,500,        3 },
	{ "Pragha",      NULL,       NULL,       0,            1,           -1,        50,50,500,500,        3 },
	{ "Pavucontrol", NULL,       NULL,       0,            1,           -1,        50,50,500,500,        3 },
	{ "Galculator",  NULL,       NULL,       0,            1,           -1,        50,50,500,500,        3 },
	{ "Xcalc",       NULL,       NULL,       0,            1,           -1,        50,50,500,500,        3 },
	{ "Yad",         NULL,       NULL,       0,            1,           -1,        590,500,100,50,       3 },
	{ "bright-gamma",NULL,       NULL,       0,            1,           -1,        590,500,100,50,       3 },
	{ "feh",         NULL,       NULL,       0,            1,           -1,        550,300,800,520,      3 },
	{ "Firefox",     NULL,       NULL,       1 << 8,       0,           -1,        50,50,500,500,        3 },
	{ "Transmission-gtk", NULL,  NULL,       0,            1,           -1,        50,50,500,500,        3 },
	{ "brightness_001",   NULL,  NULL,       0,            1,           -1,        30,50,200,30,         3 },
    { "live-usb-maker-gui-antix",NULL,       NULL,       0,            1,           -1,        50,50,500,500,        3 },
};

/* layout(s) */
static const float mfact     = 0.55; /* factor of master area size [0.05..0.95] */
static const int nmaster     = 1;    /* number of clients in master area */
static const int resizehints = 0;    /* 1 means respect size hints in tiled resizals */
static const int lockfullscreen = 1; /* 1 will force focus on the fullscreen window */

static const Layout layouts[] = {
	/* symbol     arrange function */
	{ "[]=",      tile },    /* first entry is default */
	{ "><>",      NULL },    /* no layout function means floating behavior */
	{ "[M]",      monocle },
};

/* key definitions */
#define MODKEY Mod4Mask
#define ALTKEY Mod1Mask
#define TAGKEYS(KEY,TAG) \
	{ MODKEY,                       KEY,      view,           {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask,           KEY,      toggleview,     {.ui = 1 << TAG} }, \
	{ MODKEY|ShiftMask,             KEY,      tag,            {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask|ShiftMask, KEY,      toggletag,      {.ui = 1 << TAG} },

/* helper for spawning shell commands in the pre dwm-5.0 fashion */
#define SHCMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

/* commands */
static char dmenumon[2] = "0"; /* component of dmenucmd, manipulated in spawn() */
static const char *dmenucmd[] = { "dmenu_run", "-m", dmenumon, "-fn", dmenufont, "-nb", col_gray1, "-nf", col_gray3, "-sb", col_cyan, "-sf", col_gray4, NULL };
static const char *roficmd[]  = { "rofi", "-show", "drun", NULL };
static const char *termcmd[]  = { "x-terminal-emulator", NULL };
static const char *filecmd[]  = { "thunar", NULL };
static const char *editcmd[]  = { "geany", NULL };
static const char *exitcmd[]  = { "ld-logout", NULL };
static const char *jgmenucmd[]  = { "jgmenu", NULL };
static const char *officecmd[]  = { "libreoffice", NULL };
static const char *musiccmd[]   = { "pragha", NULL };
static const char *soundcmd[]   = { "pavucontrol", NULL };
static const char *browsercmd[] = { "x-www-browser", NULL };
static const char *screencmd[]  = { "xfce4-screenshooter", NULL };
static const char *scrotcmd[]   = { "scrot-options", NULL };
static const char *wallpapercmd[] = { "feh-set-wallpaper", NULL };
static const char *playnext[]	= { "pragha", "-n", NULL };
static const char *playprev[]	= { "pragha", "-r", NULL };
static const char *playpause[]	= { "pragha", "-t", NULL };
/* pulse tools */
static const char *volup[]	= { "pamixer", "-i", "5", NULL };
static const char *voldown[]	= { "pamixer", "-d", "5", NULL };
static const char *volmute[]	= { "pamixer", "-t", NULL };
/* brightness */
static const char *brighter[] = { "brightnessctl", "set", "+10%", NULL };
static const char *dimmer[]   = { "brightnessctl", "set", "10%-", NULL };

static const Key keys[] = {
	/* modifier                     key        function        argument */
	{ MODKEY,                       XK_F1,     spawn,          {.v = jgmenucmd } },
	{ MODKEY,                       XK_F2,     spawn,          {.v = soundcmd } },
	{ MODKEY,                       XK_F3,     spawn,          {.v = roficmd } },
	{ MODKEY,                       XK_F5,     spawn,          {.v = dmenucmd } },
	{ MODKEY,                       XK_p,      spawn,          {.v = musiccmd } },
	{ MODKEY,                       XK_b,      spawn,          {.v = browsercmd } },
	{ MODKEY,                       XK_w,      spawn,          {.v = wallpapercmd } },
	{ MODKEY,                       XK_o,      spawn,          {.v = officecmd } },
	{ MODKEY,                       XK_e,      spawn,          {.v = editcmd } },
	{ MODKEY,                       XK_x,      spawn,          {.v = exitcmd } },
	{ MODKEY,                       XK_f,      spawn,          {.v = filecmd } },
	{ MODKEY,                       XK_t,      spawn,          {.v = termcmd } },
	{ MODKEY,                       XK_Return, spawn,          {.v = termcmd } },
	{ ALTKEY,                       XK_Print,  spawn,          {.v = scrotcmd } },
	{ 0,                            XK_Print,  spawn,          {.v = screencmd } },
	{ 0,              XF86XK_AudioRaiseVolume, spawn,          {.v = volup } },
	{ 0,              XF86XK_AudioLowerVolume, spawn,          {.v = voldown } },
	{ 0,              XF86XK_AudioMute,        spawn,          {.v = volmute } },
	{ 0,              XF86XK_AudioPlay,        spawn,          {.v = playpause } },
	{ 0,              XF86XK_AudioNext,        spawn,          {.v = playnext } },
	{ 0,              XF86XK_AudioPrev,        spawn,          {.v = playprev } },
	{ 0,              XF86XK_MonBrightnessUp,  spawn,          {.v = brighter } },
	{ 0,              XF86XK_MonBrightnessDown,spawn,          {.v = dimmer } },
	{ MODKEY|ShiftMask,             XK_b,      togglebar,      {0} },
	{ MODKEY,                       XK_j,      focusstackvis,  {.i = +1 } },
	{ MODKEY,                       XK_k,      focusstackvis,  {.i = -1 } },
	{ MODKEY|ShiftMask,             XK_j,      focusstackhid,  {.i = +1 } },
	{ MODKEY|ShiftMask,             XK_k,      focusstackhid,  {.i = -1 } },
	{ MODKEY|ShiftMask,             XK_h,      rotatestack,    {.i = +1 } },
	{ MODKEY|ShiftMask,             XK_l,      rotatestack,    {.i = -1 } },
	{ MODKEY,                       XK_i,      incnmaster,     {.i = +1 } },
	{ MODKEY,                       XK_d,      incnmaster,     {.i = -1 } },
	{ MODKEY,                       XK_h,      setmfact,       {.f = -0.05} },
	{ MODKEY,                       XK_l,      setmfact,       {.f = +0.05} },
	{ ALTKEY,                       XK_Return, zoom,           {0} },
	{ MODKEY,                       XK_Tab,    view,           {0} },
	{ ALTKEY|ShiftMask,             XK_c,      killclient,     {0} },
	{ ALTKEY,                       XK_t,      setlayout,      {.v = &layouts[0]} },
	{ ALTKEY,                       XK_f,      setlayout,      {.v = &layouts[1]} },
	{ ALTKEY,                       XK_m,      setlayout,      {.v = &layouts[2]} },
	{ MODKEY,                       XK_space,  setlayout,      {0} },
	{ MODKEY|ShiftMask,             XK_space,  togglefloating, {0} },
	{ MODKEY,                       XK_Down,   moveresize,     {.v = "0x 25y 0w 0h" } },
	{ MODKEY,                       XK_Up,     moveresize,     {.v = "0x -25y 0w 0h" } },
	{ MODKEY,                       XK_Right,  moveresize,     {.v = "25x 0y 0w 0h" } },
	{ MODKEY,                       XK_Left,   moveresize,     {.v = "-25x 0y 0w 0h" } },
	{ MODKEY|ShiftMask,             XK_Down,   moveresize,     {.v = "0x 0y 0w 25h" } },
	{ MODKEY|ShiftMask,             XK_Up,     moveresize,     {.v = "0x 0y 0w -25h" } },
	{ MODKEY|ShiftMask,             XK_Right,  moveresize,     {.v = "0x 0y 25w 0h" } },
	{ MODKEY|ShiftMask,             XK_Left,   moveresize,     {.v = "0x 0y -25w 0h" } },
	{ ALTKEY,                       XK_Up,     moveresizeedge, {.v = "t"} },
	{ ALTKEY,                       XK_Down,   moveresizeedge, {.v = "b"} },
	{ ALTKEY,                       XK_Left,   moveresizeedge, {.v = "l"} },
	{ ALTKEY,                       XK_Right,  moveresizeedge, {.v = "r"} },
	{ ALTKEY|ShiftMask,             XK_Up,     moveresizeedge, {.v = "T"} },
	{ ALTKEY|ShiftMask,             XK_Down,   moveresizeedge, {.v = "B"} },
	{ ALTKEY|ShiftMask,             XK_Left,   moveresizeedge, {.v = "L"} },
	{ ALTKEY|ShiftMask,             XK_Right,  moveresizeedge, {.v = "R"} },
	{ MODKEY,                       XK_0,      view,           {.ui = ~0 } },
	{ MODKEY|ShiftMask,             XK_0,      tag,            {.ui = ~0 } },
	{ MODKEY,                       XK_comma,  focusmon,       {.i = -1 } },
	{ MODKEY,                       XK_period, focusmon,       {.i = +1 } },
	{ MODKEY|ShiftMask,             XK_comma,  tagmon,         {.i = -1 } },
	{ MODKEY|ShiftMask,             XK_period, tagmon,         {.i = +1 } },
	{ MODKEY,                       XK_s,      show,           {0} },
	{ MODKEY|ShiftMask,             XK_s,      showall,        {0} },
	{ ALTKEY,                       XK_h,      hide,           {0} },
	{ MODKEY,                       XK_minus,  setgaps,        {.i = -5 } },
	{ MODKEY,                       XK_equal,  setgaps,        {.i = +5 } },
	{ MODKEY|ShiftMask,             XK_minus,  setgaps,        {.i = GAP_RESET } },
	{ MODKEY|ShiftMask,             XK_equal,  setgaps,        {.i = GAP_TOGGLE} },
	TAGKEYS(                        XK_1,                      0)
	TAGKEYS(                        XK_2,                      1)
	TAGKEYS(                        XK_3,                      2)
	TAGKEYS(                        XK_4,                      3)
	TAGKEYS(                        XK_5,                      4)
	TAGKEYS(                        XK_6,                      5)
	TAGKEYS(                        XK_7,                      6)
	TAGKEYS(                        XK_8,                      7)
	TAGKEYS(                        XK_9,                      8)
	{ ALTKEY|ShiftMask,             XK_q,      quit,           {0} },
};

/* button definitions */
/* click can be ClkTagBar, ClkLtSymbol, ClkStatusText, ClkWinTitle, ClkClientWin, or ClkRootWin */
static const Button buttons[] = {
	/* click                event mask      button          function        argument */
	{ ClkButton,            0,              Button1,        spawn,          {.v = jgmenucmd } },
	{ ClkLtSymbol,          0,              Button1,        setlayout,      {0} },
	{ ClkLtSymbol,          0,              Button3,        setlayout,      {.v = &layouts[2]} },
	{ ClkWinTitle,          0,              Button1,        togglewin,      {0} },
	{ ClkWinTitle,          0,              Button2,        zoom,           {0} },
	{ ClkStatusText,        0,              Button2,        spawn,          {.v = termcmd } },
	{ ClkClientWin,         MODKEY,         Button1,        movemouse,      {0} },
	{ ClkClientWin,         MODKEY,         Button2,        togglefloating, {0} },
	{ ClkClientWin,         MODKEY,         Button3,        resizemouse,    {0} },
	{ ClkTagBar,            0,              Button1,        view,           {0} },
	{ ClkTagBar,            0,              Button3,        toggleview,     {0} },
	{ ClkTagBar,            MODKEY,         Button1,        tag,            {0} },
	{ ClkTagBar,            MODKEY,         Button3,        toggletag,      {0} },
};

