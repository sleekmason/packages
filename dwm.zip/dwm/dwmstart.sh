#!/bin/sh
# Place items you want started when dwm starts, here. Make sure to add
# an '&' symbol. 
xfsettingsd --daemon &
/usr/libexec/polkit-mate-authentication-agent-1 &
slstatus &
~/.fehbg &
pnmixer &
picom &
# Start dwm
exec dwm
