#!/bin/sh
# Place items you want started when dwm starts, here. Make sure to add
# an '&' symbol. 
xfsettingsd --daemon &
lxpolkit &
slstatus &
~/.fehbg &
pnmixer &
picom &
# Start dwm
exec dwm
