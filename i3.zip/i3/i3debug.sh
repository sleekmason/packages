#!/bin/sh
# Place items you want started when dwm starts, here. Make sure to add
# an '&' symbol. 
xfsettingsd --daemon &
lxpolkit &
slstatus &
~/.fehbg &
pnmixer &
picom &
bright-gamma &
nm-applet &
sleep 20 && kdocker -i "/usr/share/icons/hicolor/16x16/apps/thunderbird.png" -jl thunderbird >/dev/null 2>&1 &
# Start i3 with debug log
Exec=i3-with-shmlog
