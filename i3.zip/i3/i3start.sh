#!/bin/sh
# Place items you want started when dwm starts, here. Make sure to add
# an '&' symbol. 
xfsettingsd --daemon &
lxpolkit &
~/.fehbg &
pnmixer &
# picom &
nm-applet &
# Start i3
exec i3
