#!/bin/dash
conky -c ~/.config/lemonbar/conky-lemonbar | lemonbar \
-f -*-"*-15"-* \
-g x26 \
-B "#172126" \
-F "#C7C7BF" \
| sh
