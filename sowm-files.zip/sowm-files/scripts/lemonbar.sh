#!/bin/dash
conky -c ~/.config/lemonbar/conky-lemonbar | lemonbar \
-f "DeJavu:size=12" \
-g x24 \
-B "#11171A" \
-F "#C7C7BF" \
| sh
