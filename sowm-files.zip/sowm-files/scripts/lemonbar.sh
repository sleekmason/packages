#!/bin/dash
conky -c ~/.config/lemonbar/conky-lemonbar | lemonbar \
-f "DeJavu:size=12" \
-g x24 \
-B "#0D1214" \
-F "#ACB9C2" \
| sh
