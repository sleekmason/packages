#!/bin/dash
conky -c ~/.config/lemonbar/conky-lemonbar | lemonbar \
-f "DeJavu:size=12" \
-g x24 \
-B "#131B1F" \
-F "#C7C7BF" \
| sh
