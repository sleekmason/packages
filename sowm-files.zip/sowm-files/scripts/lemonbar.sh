#!/bin/dash
conky -c ~/.config/sowm/conky-lemonbar | lemonbar \
-f -*-"*-15"-* \
-g x26 \
-B "#172126" \
-F "#C7C7BF" \
| sh
