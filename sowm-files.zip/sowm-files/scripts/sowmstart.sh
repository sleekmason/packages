#!/bin/sh
xfsettingsd --daemon &
lxpolkit &
. $HOME/.fehbg &
~/.config/lemonbar/lemonbar.sh &

exec sowm
