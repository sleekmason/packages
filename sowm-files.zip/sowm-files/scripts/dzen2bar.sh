#!/bin/dash
conky -c ~/.config/dzen2bar/conky-dzen2bar | dzen2 \
| sh
