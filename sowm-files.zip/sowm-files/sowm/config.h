#ifndef CONFIG_H
#define CONFIG_H

#define MOD Mod4Mask
#define RAISE_ON_FOCUS  0 // 1 for true, 0 for false

const char* browser[]     = {"x-www-browser",          0};
const char* jgmenu[]      = {"jgmenu",                 0};
const char* rofimenu[]    = { "rofi", "-show", "drun", 0};
const char* dmenu[]       = {"dmenu_run",              0};
const char* dmenu2[]      = {"dmenu_run",              0};
const char* thunar[]      = {"thunar",                 0};
const char* geany[]       = {"geany",                  0};
const char* nano[]        = {"nano",                   0};
const char* exit2[]       = {"ld-logout",              0};
const char* themes[]      = {"ld-themes",              0};
const char* lemonbar[]    = {"toggle.lemonbar",        0};
const char* term[]        = {"xfce4-terminal",         0};
const char* term2[]       = {"xfce4-terminal",         0};
const char* scrot[]       = {"xfce4-screenshooter",    0};
const char* briup[]       = {"bri", "10", "+",         0};
const char* bridown[]     = {"bri", "10", "-",         0};
const char* voldown[]     = {"amixer", "sset", "Master", "5%-",    0};
const char* volup[]       = {"amixer", "sset", "Master", "5%+",    0};
const char* volmute[]     = {"amixer", "sset", "Master", "toggle", 0};
const char* wallpaper[]   = {"/usr/local/bin/feh-set-wallpaper",   0};

static struct key keys[] = {
    {MOD,      XK_q,   win_kill,   {0}},
    {MOD,      XK_c,   win_center, {0}},
    {MOD|ShiftMask,  XK_f,   win_fs,     {0}},

    {MOD,           XK_k,  win_move,  {.com = (const char*[]){"move",   "n"}, .i = 10}},
    {MOD,           XK_j,  win_move,  {.com = (const char*[]){"move",   "s"}, .i = 10}},
    {MOD,           XK_l,  win_move,  {.com = (const char*[]){"move",   "e"}, .i = 10}},
    {MOD,           XK_h,  win_move,  {.com = (const char*[]){"move",   "w"}, .i = 10}},

    {MOD|ShiftMask, XK_k,  win_move,  {.com = (const char*[]){"resize", "n"}, .i = 10}},
    {MOD|ShiftMask, XK_j,  win_move,  {.com = (const char*[]){"resize", "s"}, .i = 10}},
    {MOD|ShiftMask, XK_l,  win_move,  {.com = (const char*[]){"resize", "e"}, .i = 10}},
    {MOD|ShiftMask, XK_h,  win_move,  {.com = (const char*[]){"resize", "w"}, .i = 10}},

    {Mod1Mask,           XK_Tab, win_next,   {0}},
    {Mod1Mask|ShiftMask, XK_Tab, win_prev,   {0}},

    {MOD, XK_b,      run, {.com = browser}},
    {MOD, XK_F1,     run, {.com = jgmenu}},
    {MOD, XK_F3,     run, {.com = rofimenu}},
    {MOD, XK_d,      run, {.com = dmenu}},
    {MOD, XK_F5,     run, {.com = dmenu2}},
    {MOD, XK_w,      run, {.com = wallpaper}},
    {MOD, XK_z,      run, {.com = lemonbar}},
    {MOD, XK_F7,     run, {.com = themes}},
    {MOD, XK_e,      run, {.com = geany}},
    {MOD, XK_n,      run, {.com = nano}},
    {MOD, XK_f,      run, {.com = thunar}},
    {MOD, XK_x,      run, {.com = exit2}},
    {MOD, XK_Print,  run, {.com = scrot}},
    {MOD, XK_Return, run, {.com = term}},
    {MOD, XK_t,      run, {.com = term2}},

    {0,   XF86XK_AudioLowerVolume,  run, {.com = voldown}},
    {0,   XF86XK_AudioRaiseVolume,  run, {.com = volup}},
    {0,   XF86XK_AudioMute,         run, {.com = volmute}},
    {0,   XF86XK_MonBrightnessUp,   run, {.com = briup}},
    {0,   XF86XK_MonBrightnessDown, run, {.com = bridown}},

    {MOD,           XK_1, ws_go,     {.i = 1}},
    {MOD|ShiftMask, XK_1, win_to_ws, {.i = 1}},
    {MOD,           XK_2, ws_go,     {.i = 2}},
    {MOD|ShiftMask, XK_2, win_to_ws, {.i = 2}},
    {MOD,           XK_3, ws_go,     {.i = 3}},
    {MOD|ShiftMask, XK_3, win_to_ws, {.i = 3}},
    {MOD,           XK_4, ws_go,     {.i = 4}},
    {MOD|ShiftMask, XK_4, win_to_ws, {.i = 4}},
    {MOD,           XK_5, ws_go,     {.i = 5}},
    {MOD|ShiftMask, XK_5, win_to_ws, {.i = 5}},
    {MOD,           XK_6, ws_go,     {.i = 6}},
    {MOD|ShiftMask, XK_6, win_to_ws, {.i = 6}},
};

#endif
