# sowm (*Lilidog version*)

## NOTE - IF INSTALLED, THIS README IS FOR REFERENCE ONLY.

In this zip file are all the **sown** related files needed to install sowm.  These are:

   - The main folder as you would grab it from git, but already patched with the move and resize patch 
     and the resultant executable after "make" if not wanting to mess with rebuilding it yourself.
   - A lemonbar binary built with xft support.  Note that the debian version does not have xft support.
   - The existing ~/.xsessionrc, amended for extra WM support, 
   - A script to allow rofi drun to function properly.
   - scripts and conkys for lemonbar and dzen2 use.
   - The sowm.desktop for /usr/share/xsessions, which will allow for lightdm use.

I've also added some keybinds to make life a little easier too. Some were already here, 
but changed to kinda match what Lilidog uses.

## Keybinds

| combo                      | action                 |
| -------------------------- | -----------------------|
| `Mouse`                    | focus under cursor     |
| `MOD4` + `Left Mouse`      | move window            |
| `MOD4` + `Right Mouse`     | resize window          |
| `MOD4 + Shift` + `f`       | maximize toggle        |
| `MOD4` + `c`               | center window          |
| `MOD4` + `q`               | kill window            |
| `MOD4` + `1-6`             | desktop swap           |
| `MOD4` + `Shift` +`1-6`    | send window to desktop |
| `MOD1` + `TAB` (*alt-tab*) | focus cycle            |

**Programs**

| combo                    | action           | program        |
| ------------------------ | ---------------- | -------------- |
| `MOD4` + `Return`        | terminal         | `st`           |
| `MOD4` + `d`             | dmenu            | `dmenu_run`    |
| `XF86_AudioLowerVolume`  | volume down      | `amixer`       |
| `XF86_AudioRaiseVolume`  | volume up        | `amixer`       |
| `XF86_AudioMute`         | volume toggle    | `amixer`       |
| `XF86_MonBrightnessUp`   | brightness up    | `bri`          |
| `XF86_MonBrightnessDown` | brightness down  | `bri`          |


## Lilidog added keybinds

| Program|keybind |                
| -------------------------- | -----------------------|
| | browser | 'super +b' |  Use "galternatives" to change
| jgmenu | 'super + F1'|
| rofi menu | 'super + F3'|
| dmenu | 'super + d'|
| dmenu2 (alternate) | 'super + F5'|
| thunar | 'super + f'|
| lemonbar | 'super + z'|
| geany | 'super + e'|
| nano | 'super + n' |
| exit2 | 'super + x'|
| themes | 'super + F7'|
| xce4-terminal | 'super + Return'|
| xce4-terminal | 'super + t'|
| xfce4-screenshooter | 'super + Print'|
| wallpaper | 'super + w'|

### To use the existing **sowm** executable (binary) after unzipping the file:

 - Place /sowm/sowm into /usr/bin. (important if rebuilding later) sudo make install will do this.
 - From the lemonbar-xft folder, place /lemonbar-xft/lemonbar into /usr/local/bin.
 - From the scripts folder, place toggle.lemonbar toggle.dzen2bar, and rofi-drun, into either
  ~/bin to test, or /usr/local/bin for build purposes.
 - Make a folder ~/.config/sowm and from the scripts folder, place 'sowmstart.sh inside.
 - Make folders in ~/.config for lemonbar and dzen2bar, and then place the relevant
   conkys from the conkys folder, and the relevant scripts from the scripts folder into 
   their respective ~/.config folders (lemonbar and dzen2bar).
 - Add the sowm.desktop file to /usr/share/xsessions for lightdm use.
 - rename ~/.xsessionrc to ~/.xsessionrc.bak and add the .xsessionrc in its place.
 - For lemonbar and dzen2 use:  sudo apt update && sudo apt install dzen2 conky-all

### To use
 - If using lightdm, logout and select **sowm**, and log back in.
 - If using startx, uncomment the second to last line #exec "$session" and change the name 
   above to your desired wm.

### To build
You can also build sowm with your own keybind choices by editing 'config.h' in the sowm folder.
First you will need the build dependencies: sudo apt update && sudo apt install libx11-dev build-essential libxinerama-dev
Then in the sowm folder from a terminal: 'make clean' then 'make', and finally 'sudo make install' to 
install sowm to /usr/bin on your system.

See: https://forum.lilidog.org/d/814-conky-fan-speed-temperature-battery-wifi-device to adjust top bar settings.

Good luck in your endeavors!
