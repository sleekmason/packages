# zwlr_gamma_control_manager_v1.py — pywayland bindings for zwlr_gamma_control_manager_v1
#
# Derived from the wlr-gamma-control-unstable-v1 Wayland protocol definition.
#
# Copyright © 2015 Giulio Camuffo
# Copyright © 2018 Simon Ser
#
# Permission to use, copy, modify, distribute, and sell this software and
# its documentation for any purpose is hereby granted without fee, provided
# that the above copyright notice appear in all copies and that both that
# copyright notice and this permission notice appear in supporting
# documentation, and that the name of the copyright holders not be used in
# advertising or publicity pertaining to distribution of the software without
# specific, written prior permission. The copyright holders make no
# representations about the suitability of this software for any purpose.
# It is provided "as is" without express or implied warranty.
#
# THE COPYRIGHT HOLDERS DISCLAIM ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
# INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT
# SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR
# CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
# DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
# OF THIS SOFTWARE.

from __future__ import annotations

from pywayland.protocol_core import (
    Argument,
    ArgumentType,
    Global,
    Interface,
    Proxy,
    Resource,
)
from pywayland.protocol.wayland import WlOutput

from .zwlr_gamma_control_v1 import ZwlrGammaControlV1


class ZwlrGammaControlManagerV1(Interface):
    """Manager to create per-output gamma controls.

    This interface is a manager that allows creating per-output gamma
    controls.
    """

    name = "zwlr_gamma_control_manager_v1"
    version = 1


class ZwlrGammaControlManagerV1Proxy(Proxy[ZwlrGammaControlManagerV1]):
    interface = ZwlrGammaControlManagerV1

    @ZwlrGammaControlManagerV1.request(
        Argument(ArgumentType.NewId, interface=ZwlrGammaControlV1),
        Argument(ArgumentType.Object, interface=WlOutput),
    )
    def get_gamma_control(self, output: Proxy) -> Proxy[ZwlrGammaControlV1]:
        """Get a gamma control for an output.

        Create a gamma control that can be used to adjust gamma tables for
        the provided output.

        :param output:
            the wl_output to control
        :returns:
            :class:`ZwlrGammaControlV1` -- the gamma control object
        """
        id = self._marshal_constructor(0, ZwlrGammaControlV1, output)
        return id

    @ZwlrGammaControlManagerV1.request()
    def destroy(self) -> None:
        """Destroy the manager."""
        self._marshal(1)
        self._destroy()


class ZwlrGammaControlManagerV1Resource(Resource):
    interface = ZwlrGammaControlManagerV1


class ZwlrGammaControlManagerV1Global(Global):
    interface = ZwlrGammaControlManagerV1


ZwlrGammaControlManagerV1._gen_c()
ZwlrGammaControlManagerV1.proxy_class = ZwlrGammaControlManagerV1Proxy
ZwlrGammaControlManagerV1.resource_class = ZwlrGammaControlManagerV1Resource
ZwlrGammaControlManagerV1.global_class = ZwlrGammaControlManagerV1Global
