# zwlr_gamma_control_v1.py — pywayland bindings for zwlr_gamma_control_v1
#
# Derived from the wlr-gamma-control-unstable-v1 Wayland protocol definition.
#
# Copyright © 2015 Giulio Camuffo
# Copyright © 2018 Simon Ser
#
# Permission to use, copy, modify, distribute, and sell this software and
# its documentation for any purpose is hereby granted without fee, provided
# that the above copyright notice appear in all copies and that both that
# copyright notice and this permission notice appear in supporting
# documentation, and that the name of the copyright holders not be used in
# advertising or publicity pertaining to distribution of the software without
# specific, written prior permission. The copyright holders make no
# representations about the suitability of this software for any purpose.
# It is provided "as is" without express or implied warranty.
#
# THE COPYRIGHT HOLDERS DISCLAIM ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
# INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT
# SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR
# CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
# DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
# OF THIS SOFTWARE.

from __future__ import annotations

import enum

from pywayland.protocol_core import (
    Argument,
    ArgumentType,
    Global,
    Interface,
    Proxy,
    Resource,
)


class ZwlrGammaControlV1(Interface):
    """Adjust gamma tables for an output.

    This interface allows a client to adjust gamma tables for a particular
    output. At most one client can have a gamma control for a given output
    at a time.
    """

    name = "zwlr_gamma_control_v1"
    version = 1

    class error(enum.IntEnum):
        invalid_gamma = 1


class ZwlrGammaControlV1Proxy(Proxy[ZwlrGammaControlV1]):
    interface = ZwlrGammaControlV1

    @ZwlrGammaControlV1.request(
        Argument(ArgumentType.FileDescriptor),
    )
    def set_gamma(self, fd: int) -> None:
        """Set the gamma tables for the associated output.

        The fd must refer to a shared memory object containing 3 * size
        uint16 values (red, green, blue ramps), where size was received
        in the gamma_size event.

        :param fd:
            file descriptor for shared memory containing gamma ramps
        :type fd:
            `ArgumentType.FileDescriptor`
        """
        self._marshal(0, fd)

    @ZwlrGammaControlV1.request()
    def destroy(self) -> None:
        """Destroy this object.

        Destroys the gamma control object. If the object is still valid,
        this restores the original gamma tables of the output.
        """
        self._marshal(1)
        self._destroy()


class ZwlrGammaControlV1Resource(Resource):
    interface = ZwlrGammaControlV1

    @ZwlrGammaControlV1.event(
        Argument(ArgumentType.Uint),
    )
    def gamma_size(self, size: int) -> None:
        """Size of gamma ramps.

        Provides the gamma ramp size. Sent immediately after binding.

        :param size:
            number of elements in a ramp
        :type size:
            `ArgumentType.Uint`
        """
        self._post_event(0, size)

    @ZwlrGammaControlV1.event()
    def failed(self) -> None:
        """Object no longer valid.

        Emitted when the gamma control is no longer valid (e.g. output
        doesn't support gamma, another client holds it, compositor revoked).
        """
        self._post_event(1)


class ZwlrGammaControlV1Global(Global):
    interface = ZwlrGammaControlV1


ZwlrGammaControlV1._gen_c()
ZwlrGammaControlV1.proxy_class = ZwlrGammaControlV1Proxy
ZwlrGammaControlV1.resource_class = ZwlrGammaControlV1Resource
ZwlrGammaControlV1.global_class = ZwlrGammaControlV1Global
