from .zwlr_gamma_control_manager_v1 import ZwlrGammaControlManagerV1
from .zwlr_gamma_control_v1 import ZwlrGammaControlV1

__all__ = ["ZwlrGammaControlManagerV1", "ZwlrGammaControlV1"]
