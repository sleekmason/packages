#!/bin/bash
# Mangowm keybinds
# Created for Waydog by sleekmason 1 Jun 2026

# Edit here to add readable labels to existing items.
declare -A FRIENDLY_NAMES=(
    ["x-terminal-emulator"]="Terminal"
    ["x-www-browser"]="Browser"
    ["xfce4-terminal"]="Terminal"
    ["fuzzel"]="Fuzzel Launcher"
    ["wdmenu"]="wdmenu Launcher"
    ["thunar"]="Thunar Files"
    ["geany"]="Geany Editor"
    ["random-wallpaper once"]="Random Wallpaper - Once"
    ["toggle-random"]="Random Wallpaper - Daemon"
    ["waypaper-update-wrapper"]="Wallpapers"
    ["waybar-toggle"]="Waybar On/Off"
    ["waybar-icon-toggle dialog"]="Waybar Options"
    ["grimshot save area"]="Screenshot Area"
    ["wlr-gamma-tool -r -a"]="Gamma - Reset"
    ["wlr-gamma-tool"]="Gamma - Reset"
    ["wlr-gamma-gui"]="Gamma Control"
    ["hotcorners-toggle"]="Hotcorners On/Off"
    ["conky-chooser"]="Conky Chooser - if installed"
    ["ld-logout"]="Logout"
    ["mango-keys"]="Keybinds MangoWM"
)

CONFIG="$HOME/.config/mango/config.conf"

if command -v x-terminal-emulator >/dev/null 2>&1; then
    REAL_TERM=$(basename "$(readlink -f "$(command -v x-terminal-emulator)")")
else
    notify-send "mango-keys" "No terminal emulator found"
    exit 1
fi

run_in_terminal() {
    SCRIPT="$1"
    case "$REAL_TERM" in
        ghostty)        x-terminal-emulator --title="MangoWM Keybinds" -e "$SCRIPT" ;;
        xfce4-terminal) x-terminal-emulator -T "MangoWM Keybinds" -x "$SCRIPT" ;;
        alacritty)      x-terminal-emulator --title "MangoWM Keybinds" -e "$SCRIPT" ;;
        gnome-terminal) x-terminal-emulator -T "MangoWM Keybinds" -- "$SCRIPT" ;;
        foot)           x-terminal-emulator --title="MangoWM Keybinds" -e "$SCRIPT" ;;
        kitty)          x-terminal-emulator --title="MangoWM Keybinds" -e "$SCRIPT" ;;
        wezterm)        x-terminal-emulator start --title "MangoWM Keybinds" "$SCRIPT" ;;
        *)              x-terminal-emulator -e "$SCRIPT" ;;
    esac
}

TMP_NAMES=$(mktemp)
for key in "${!FRIENDLY_NAMES[@]}"; do
    printf '%s\t%s\n' "$key" "${FRIENDLY_NAMES[$key]}"
done > "$TMP_NAMES"

TMP_SCRIPT=$(mktemp)

cat >"$TMP_SCRIPT" <<EOF
#!/bin/bash
CONFIG="\$HOME/.config/mango/config.conf"
NAMES_FILE="$TMP_NAMES"
clear

HEAD_COLOR="\033[94m"
GREEN="\033[32m"
BLUE="\033[34m"
RESET="\033[0m"

echo -e " \${BLUE}MANGO KEYBINDS   Legend: Super  Alt  C=Ctrl  Sh=Shift\${RESET}"
echo -e " \${GREEN}---------------------------------------------------------\${RESET}"

awk -v HEAD="\$HEAD_COLOR" -v RESET="\$RESET" '
BEGIN {
    CKEY="\033[33m"
    CACT="\033[32m"
    CDET="\033[34m"
    width_key=22
    width_act=14
    max_detail=46

    order_n = 0
    order[++order_n] = "Config"
    order[++order_n] = "Launch"
    order[++order_n] = "Wallpaper"
    order[++order_n] = "Bar"
    order[++order_n] = "Session"
    order[++order_n] = "Window"
    order[++order_n] = "Focus"
    order[++order_n] = "Move"
    order[++order_n] = "Send"
    order[++order_n] = "Tag"
    order[++order_n] = "Resize"
    order[++order_n] = "Layout"
    order[++order_n] = "Scroller"
    order[++order_n] = "Gaps"
    order[++order_n] = "Mouse"
    order[++order_n] = "Other"

    heading["Config"]     = "[Config]"
    heading["Launch"]     = "[Launch]"
    heading["Wallpaper"]  = "[Wallpaper]"
    heading["Bar"]        = "[Bar]"
    heading["Session"]    = "[Session]"
    heading["Window"]     = "[Window]"
    heading["Focus"]      = "[Focus]"
    heading["Move"]       = "[Move]"
    heading["Send"]       = "[Send to Tag]"
    heading["Tag"]        = "[Tags]"
    heading["Resize"]     = "[Resize]"
    heading["Layout"]     = "[Layout]"
    heading["Scroller"]   = "[Scroller]"
    heading["Gaps"]       = "[Gaps]"
    heading["Mouse"]      = "[Mouse]"
    heading["Other"]      = "[Other]"

    total = 0
}

# NR==FNR: load names file (tab-separated) before processing config
# FS="\t" so keys with spaces load as a single field
NR==FNR { FS="\t"; names[\$1]=\$2; next }

/^[ \t]*(#|\$)/ { next }

/^bind=/ || /^mousebind=/ {
    is_mouse = (/^mousebind=/)
    line = \$0
    sub(/^bind=/, "", line)
    sub(/^mousebind=/, "", line)

    n = split(line, fld, /,/)
    if (n < 3) next

    mod    = fld[1]
    key    = fld[2]
    action = fld[3]

    args = ""
    for (i = 4; i <= n; i++)
        args = (i == 4) ? fld[i] : args "," fld[i]
    gsub(/^ +| +\$/, "", args)

    # Normalize mod: longest tokens first to avoid partial replacement
    gsub(/SHIFT/, "Sh",    mod)
    gsub(/SUPER/, "Super", mod)
    gsub(/ALT/,   "Alt",   mod)
    gsub(/CTRL/,  "C",     mod)
    gsub(/NONE/,  "",      mod)
    # Also normalize any lowercase compound mods (e.g. alt+shift+ctrl)
    gsub(/shift/, "Sh",    mod)
    gsub(/super/, "Super", mod)
    gsub(/alt/,   "Alt",   mod)
    gsub(/ctrl/,  "C",     mod)

    if (is_mouse)
        display_key = (mod != "") ? "M+" mod "+" key : "M+" key
    else
        display_key = (mod != "") ? mod "+" key : key

    cat = ""; detail = ""

    if (action == "spawn") {
        if      (args ~ /xfce4-terminal|alacritty|ghostty|foot|kitty|wezterm|x-terminal-emulator/) {
                                                                  cat = "Launch";     detail = args }
        else if (args ~ /fuzzel|rofi|dmenu|wdmenu/)             { cat = "Launch";     detail = args }
        else if (args ~ /x-www-browser|chromium|firefox/)       { cat = "Launch";     detail = args }
        else if (args ~ /thunar|nautilus|pcmanfm/)              { cat = "Launch";     detail = args }
        else if (args ~ /waypaper|random-wallpaper|toggle-random/) { cat = "Wallpaper"; detail = args }
        else if (args ~ /waybar/)                               { cat = "Bar";        detail = args }
        else if (args ~ /logout|ld-logout/)                     { cat = "Session";    detail = args }
        else                                                    { cat = "Launch";     detail = args }
    }
    else if (action == "killclient")                     { cat = "Window";   detail = "close" }
    else if (action == "quit")                           { cat = "Session";  detail = "quit MangoWM" }
    else if (action == "reload_config")                  { cat = "Config";   detail = "reload" }
    else if (action == "togglefloating")                 { cat = "Window";   detail = "toggle floating" }
    else if (action == "togglefullscreen")               { cat = "Window";   detail = "fullscreen" }
    else if (action == "togglefakefullscreen")           { cat = "Window";   detail = "fake fullscreen" }
    else if (action == "togglemaximizescreen")           { cat = "Window";   detail = "maximize" }
    else if (action == "toggleglobal")                   { cat = "Window";   detail = "toggle global" }
    else if (action == "toggleoverview")                 { cat = "Window";   detail = "overview" }
    else if (action == "toggleoverlay")                  { cat = "Window";   detail = "overlay" }
    else if (action == "minimized")                      { cat = "Window";   detail = "minimize" }
    else if (action == "restore_minimized")              { cat = "Window";   detail = "restore minimized" }
    else if (action == "toggle_scratchpad")              { cat = "Window";   detail = "scratchpad" }
    else if (action == "focusstack")                     { cat = "Focus";    detail = args }
    else if (action == "focusdir")                       { cat = "Focus";    detail = args }
    else if (action == "focusmon")                       { cat = "Focus";    detail = "monitor " args }
    else if (action == "exchange_client")                { cat = "Move";     detail = args }
    else if (action == "movewin")                        { cat = "Move";     detail = "pixel " args }
    else if (action == "tagmon")                         { cat = "Move";     detail = "to monitor " args }
    else if (action == "tag")                            { cat = "Send";     detail = "tag " fld[4] }
    else if (action == "tagsilent")                      { cat = "Send";     detail = "silent -> tag " fld[4] }
    else if (action == "view")                           { cat = "Tag";      detail = "go to " fld[4] }
    else if (action == "viewtoleft")                     { cat = "Tag";      detail = "<- left" }
    else if (action == "viewtoright")                    { cat = "Tag";      detail = "-> right" }
    else if (action == "viewtoleft_have_client")         { cat = "Tag";      detail = "<- left (with win)" }
    else if (action == "viewtoright_have_client")        { cat = "Tag";      detail = "-> right (with win)" }
    else if (action == "tagtoleft")                      { cat = "Tag";      detail = "send <- left" }
    else if (action == "tagtoright")                     { cat = "Tag";      detail = "send -> right" }
    else if (action == "resizewin")                      { cat = "Resize";   detail = "pixel " args }
    else if (action == "switch_layout")                  { cat = "Layout";   detail = "cycle layout" }
    else if (action == "set_proportion")                 { cat = "Layout";   detail = "proportion " args }
    else if (action == "switch_proportion_preset")       { cat = "Layout";   detail = "proportion preset" }
    else if (action == "dwindle_toggle_split_direction") { cat = "Layout";   detail = "dwindle split dir" }
    else if (action ~ /^scroller_/)                      { cat = "Scroller"; detail = args }
    else if (action == "incgaps") {
        cat = "Gaps"
        detail = (args+0 > 0) ? "increase " args : "decrease " substr(args, 2)
    }
    else if (action == "togglegaps") { cat = "Gaps";  detail = "toggle" }
    else if (action == "moveresize") { cat = "Mouse"; detail = args }
    else { cat = "Other"; detail = action (args != "" ? " " args : "") }

    if (cat == "") next

    gsub(/^ +| +\$/, "", detail)

    # Friendly name lookup: longest match
    bestlen = 0
    bestval = ""
    for (nm in names) {
        if (index(detail, nm) && length(nm) > bestlen) {
            bestval = names[nm]
            bestlen = length(nm)
        }
    }
    if (bestlen > 0) detail = bestval

    if (length(detail) > max_detail) detail = substr(detail, 1, max_detail) "..."

    formatted = sprintf(" %s%-*s%s  %s%-*s%s - %s%s%s",
        CKEY, width_key, display_key, RESET,
        CACT, width_act, cat, RESET,
        CDET, detail, RESET)

    rows[++total] = cat SUBSEP tolower(display_key) SUBSEP formatted
}

END {
    for (s = 1; s <= order_n; s++) {
        sec = order[s]

        cnt = 0
        for (r = 1; r <= total; r++) {
            split(rows[r], parts, SUBSEP)
            if (parts[1] == sec)
                tmp[++cnt] = parts[2] SUBSEP parts[3]
        }
        if (cnt == 0) continue

        for (i = 2; i <= cnt; i++) {
            val = tmp[i]
            split(val, va, SUBSEP)
            j = i - 1
            while (j >= 1) {
                split(tmp[j], vb, SUBSEP)
                if (vb[1] > va[1]) { tmp[j+1] = tmp[j]; j-- }
                else break
            }
            tmp[j+1] = val
        }

        print "\n" HEAD heading[sec] RESET
        for (i = 1; i <= cnt; i++) {
            idx = index(tmp[i], SUBSEP)
            print substr(tmp[i], idx + 1)
        }

        for (i = 1; i <= cnt; i++) delete tmp[i]
        cnt = 0
    }
}
' "\$NAMES_FILE" "\$CONFIG"

echo -e " \${GREEN}---------------------------------------------------------\${RESET}"
echo
read -n1 -s -r -p "Press any key to close..."
echo
rm -f "\$NAMES_FILE"
EOF

chmod +x "$TMP_SCRIPT"
run_in_terminal "$TMP_SCRIPT"
rm -f "$TMP_SCRIPT"
