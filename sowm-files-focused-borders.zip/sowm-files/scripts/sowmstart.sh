#!/bin/sh
xfsettingsd --daemon &
/usr/libexec/polkit-mate-authentication-agent-1 &
. $HOME/.fehbg &
~/.config/lemonbar/lemonbar.sh &

exec sowm
