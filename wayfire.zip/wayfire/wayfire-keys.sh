#!/bin/bash
# Display Wayfire keybindings
# Created for Waydog by sleekmason 3 Jan 2026

CONFIG="$HOME/.config/wayfire.ini"

# Terminal preference
TERMINALS=( "xfce4-terminal" "foot" "wezterm" "alacritty" "gnome-terminal" "kitty" "x-terminal-emulator" )

TERM_CMD=""
for term in "${TERMINALS[@]}"; do
    if command -v "$term" >/dev/null 2>&1; then
        TERM_CMD="$term"
        break
    fi
done

if [[ -z "$TERM_CMD" ]]; then
    notify-send "wayfire-keys" "No terminal emulator found"
    exit 1
fi

run_in_terminal() {
    SCRIPT="$1"
    case "$TERM_CMD" in
        xfce4-terminal) "$TERM_CMD" -x "$SCRIPT" ;;
        gnome-terminal|x-terminal-emulator) "$TERM_CMD" -- "$SCRIPT" ;;
        kitty|alacritty|wezterm|foot) "$TERM_CMD" -e "$SCRIPT" ;;
    esac
}

TMP_SCRIPT=$(mktemp)

cat >"$TMP_SCRIPT" <<'EOF'
#!/bin/bash
CONFIG="$HOME/.config/wayfire.ini"
clear

# Colors
HEAD_COLOR="\033[94m"
GREEN="\033[32m"
BLUE="\033[34m"
RESET="\033[0m"

echo -e " ${BLUE}WAYFIRE KEYBINDS   Legend: Mod=Super  S=Shift  C=Ctrl${RESET}"
echo -e " ${GREEN}--------------------------------------------------------${RESET}"

awk -v HEAD="$HEAD_COLOR" -v RESET="$RESET" '
BEGIN {
    CKEY="\033[33m"
    CACT="\033[32m"
    CDET="\033[34m"
    width_key=22
    width_act=14
}

# Store lines in arrays by action
{
    if ($0 ~ /^[ \t]*binding_/ || $0 ~ /^[ \t]*repeatable_binding_/ || $0 ~ /^[a-zA-Z0-9_-]+[ \t]*=/) {
        line=$0
        gsub(/^[ \t]+|[ \t]+$/, "", line)
        split(line, a, "=")
        key=a[1]
        val=a[2]
        gsub(/^[ \t]+|[ \t]+$/, "", key)
        gsub(/^[ \t]+|[ \t]+$/, "", val)

        # strip prefixes
        gsub(/^binding_|^repeatable_binding_/, "", key)
        gsub(/KEY_/, "", val)

        # Normalize modifier notation
        gsub(/<super>/, "Super", val)
        gsub(/<shift>/, "Shift", val)
        gsub(/<ctrl>/,  "Ctrl",  val)
        gsub(/<alt>/,   "Alt",   val)

        # convert modifier combinations to plus-sign format
        n = split(val, parts, "|")
        for (i = 1; i <= n; i++) {
            gsub(/[ ]+/, "+", parts[i])
            gsub(/^\+|\+$/, "", parts[i])
        }
        val = parts[1]
        for (i = 2; i <= n; i++) val = val " | " parts[i]

        # suppress helper command entries
        if (key ~ /^command_/) next

        action=""
        if (key ~ /keybinds|terminal|ld-logout|thunar|random|firefox|fuzzel/)
            action="User Commands"
        else if (key ~ /panel-toggle/) action="Panel"
        else if (key ~ /lock/) action="Lock"
        else if (key ~ /screenshot/) action="Screenshot"
        else if (key ~ /volume/) action="Volume"
        else if (key ~ /light/) action="Brightness"
        else if (key ~ /^(left|right|up|down)$/ || key ~ /^with_win_/) action="Workspace/Move"
        else if (key ~ /^slot_|^restore$/) action="Workspace Slots"
        else if (key == "toggle" && val ~ /E/) action="Expo"
        else if (key ~ /^select_workspace_/) action="Expo"
        else if (key ~ /^next_output/) action="Outputs"
        else if (key == "toggle" && val ~ /I/) action="Invert"
        else if (key == "toggle_menu") action="Wayfire Shell"
        else if (key ~ /^next_view|^prev_view|^activate$/ && val ~ /TAB|ESC/) action="Window Switch"
        else if (key == "activate" && val ~ /BTN_LEFT/) action="Cube"
        else next

        lines[action] = lines[action] sprintf(" %s%-*s%s  %s%-*s%s - %s%s%s\n",
            CKEY, width_key, key, RESET,
            CACT, width_act, action, RESET,
            CDET, val, RESET)
    }
}

END {
    # Define preferred print order
    preferred_order[1] = "User Commands"
    preferred_order[2] = "Cube"
    preferred_order[3] = "Panel"
    preferred_order[4] = "Lock"
    preferred_order[5] = "Screenshot"
    preferred_order[6] = "Volume"
    preferred_order[7] = "Brightness"
    preferred_order[8] = "Workspace Slots"
    preferred_order[9] = "Window Switch"
    preferred_order[10] = "Workspace/Move"
    preferred_order[11] = "Expo"
    preferred_order[12] = "Outputs"
    preferred_order[13] = "Invert"
    preferred_order[14] = "Wayfire Shell"

    for (i = 1; i <= 14; i++) {
        action = preferred_order[i]
        if (lines[action] != "") {
            print "\n" HEAD "[" action "]" RESET
            printf "%s", lines[action]
        }
    }
}
' "$CONFIG"

echo -e " ${GREEN}--------------------------------------------------------${RESET}"
echo
read -n1 -s -r -p "Press any key to close..."
echo
EOF

chmod +x "$TMP_SCRIPT"
run_in_terminal "$TMP_SCRIPT"
rm -f "$TMP_SCRIPT"
